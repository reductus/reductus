from server_flask import create_app

app = create_app()