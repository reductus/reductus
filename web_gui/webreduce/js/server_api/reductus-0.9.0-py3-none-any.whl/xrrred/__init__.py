# This program is public domain
"""
Data corrections for X-ray reflectometry.
"""
