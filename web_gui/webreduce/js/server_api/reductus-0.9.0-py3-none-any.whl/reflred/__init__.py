# This program is public domain
"""
Data corrections for reflectometry.
"""
