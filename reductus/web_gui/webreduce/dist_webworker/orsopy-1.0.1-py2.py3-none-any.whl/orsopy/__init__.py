"""Top-level package for orsopy."""

__version__ = "1.0.1"
